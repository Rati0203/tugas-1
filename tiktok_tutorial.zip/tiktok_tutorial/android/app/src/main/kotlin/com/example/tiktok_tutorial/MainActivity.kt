package com.example.tiktok_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
